#include "Student.h"
#include <iostream>
#include <string>

using namespace std;

int main()
{
   student sA;
   sA.Input();
   sA.Output();

   system("pause");
   return 0;
}

