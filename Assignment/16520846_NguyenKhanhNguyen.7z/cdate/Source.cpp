#include "CDate.h"
#include <iostream>

using namespace std;

int main()
{

   CDate cdA;
   cdA.Input();
   cdA.NextDay();
   cdA.Output();

   system("pause");
   return 0;
}

